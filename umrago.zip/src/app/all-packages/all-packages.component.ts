import { Component, OnInit, Input } from '@angular/core';
import { PackageService } from '../services/package.service';
import { ActivatedRoute, Router } from '@angular/router';
import { packages } from 'src/models/packages.model';


declare var $: any;

@Component({
  selector: 'app-all-packages',
  templateUrl: './all-packages.component.html',
  styleUrls: ['./all-packages.component.css']
})
export class AllPackagesComponent implements OnInit {
package$ : packages[];
  
  jquery_code() {


    $(document).ready(function () {


      // asNavFor: '.carousel-main'
      // // or an element
      // asNavFor: $('.carousel-main')[0]
      // asNavFor: document.querySelector('.carousel-main')
      // $('.carousel-main').flickity({
      //   autoplay: 1500,
      //   pauseAutoPlayOnHover: false,
      //   adaptiveHeight: true
      // });
      // // 2nd carousel, navigation
      // $('.carousel-nav').flickity({
      //   asNavFor: '.carousel-main',
      //   contain: true,
      //   autoplay: 1500,
      //   pageDots: false,
      //   pauseAutoPlayOnHover: false,
      //   adaptiveHeight: true
      // });


    });


  }
  constructor(private packages_service : PackageService) { }



  ngOnInit() {
    this.jquery_code();
    return this.packages_service.getPackages()
    .subscribe(data => this.package$ = data);

    




  }

}
