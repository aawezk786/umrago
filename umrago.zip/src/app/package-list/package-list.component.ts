import { Component, OnInit } from '@angular/core';
import { post } from 'selenium-webdriver/http';

declare var $: any;
declare const M;
@Component({
  selector: 'app-package-list',
  templateUrl: './package-list.component.html',
  styleUrls: ['./package-list.component.css']
})
export class PackageListComponent implements OnInit {


  constructor() { }

  ngOnInit() {
    this.jquery_code();
  }
  jquery_code() {
    $(document).ready(function () {
      $('.sidenav').sidenav({ draggable: true });


    });

    $(".switch").find("input[type=checkbox]").on("change", function () {
      var status = $(this).prop('checked');




    });
    $(document).ready(function () {
      $('.modal').modal();
    });

    document.addEventListener('DOMContentLoaded', function () {
      var elems = document.querySelectorAll('.fixed-action-btn');
      var instances = M.FloatingActionButton.init(elems, {
        direction: 'top',
        hoverEnabled: false
      });
    });


  }



}

