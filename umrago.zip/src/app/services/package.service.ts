import { Injectable } from '@angular/core';
import { packages } from 'src/models/packages.model';
import { HttpClient } from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class PackageService {
  apiurl = 'http://demo2699825.mockable.io/package'; 


  constructor(private _http : HttpClient) { }


  getPackages() {
    return this._http.get<packages[]>(this.apiurl);
    // return [
    //       {
    //         id: "1",
    //         name: "January Budget Package",
    //         description: "ghfjsdghfsdhfjdh",
    //         hotel_makkah: "Hotel Palistine"
    //       },
    //       {
    //         id: "2",
    //         name: "December Delux Package",
    //         description: "ghwerwtwetert",
    //         hotel_makkah: "Hotel Zamzaam"
    //       },
    //       {
    //         id: "3",
    //         name: "November Economic Package",
    //         description: "ghwerwtweter134wfwef23423423t",
    //         hotel_makkah: "Hotel Makkah"
    //       }
    //     ]
      
  }
 
  
  


 
  
 

}
