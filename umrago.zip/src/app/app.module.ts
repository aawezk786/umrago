import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { PackageService } from './services/package.service';
import  { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { PackageListComponent } from './package-list/package-list.component';
import { FooterComponent } from './footer/footer.component';
import { LandingComponent } from './landing/landing.component';
import { LoginComponent } from './login/login.component';
import { OtploginComponent } from './otplogin/otplogin.component';
import { AllPackagesComponent } from './all-packages/all-packages.component';
import { DetailsComponent } from './details/details.component';
import { PaymentPanelComponent } from './payment-panel/payment-panel.component';
import { AgentregComponent } from './registration/agentreg/agentreg.component';
import { OrganizerComponent } from './registration/organizer/organizer.component';
import { CarouselComponent } from './carousel/carousel.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    PackageListComponent,
    FooterComponent,
    LandingComponent,
    LoginComponent,
    AgentregComponent,
    OrganizerComponent,
    OtploginComponent,
    AllPackagesComponent,
    DetailsComponent,
    PaymentPanelComponent,
    CarouselComponent
   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot([
      {
        path : '',
        component: LoginComponent 
      },
      {
        path : 'details/:packagename',
        component: DetailsComponent
      },
      {
        path : 'packagelist',
        component: PackageListComponent 
      },
      {
        path : 'details',
        component : DetailsComponent
      },
      {
        path : 'agent',
        component : AgentregComponent
      },
      {
        path : 'organizer',
        component : OrganizerComponent
      },
      {
        path : 'login',
        component : LoginComponent
      }
      


    ])
  ],
  providers: [PackageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
