import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PackageService } from '../services/package.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  packages: any;
 
  constructor(private route: ActivatedRoute,private newService: PackageService ) {
   
   }

  ngOnInit() {
    this.packages=this.newService.getPackages();
    //  this.route.paramMap.subscribe(params => {
    //   this.id = +params.get('id');
    //   this.newService.get(this.id);
      
    // });

   
  }

}
