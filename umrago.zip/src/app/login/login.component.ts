import { Component, OnInit } from '@angular/core';
declare var $: any;
declare const angular;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $('#textarea1').val('');
    this.jquery_code();
    //M.textareaAutoResize($('#textarea1'));
  }

  jquery_code() {
    var app = angular.module('MyApp', [])
  app.controller('MyController', function ($scope) {
    
    $scope.IsDisabled = true;
    $scope.EnableDisable = function () {
      $scope.IsDisabled = $scope.PhoneNumber.length == 0;
     
    }
   
  });

  }

}
