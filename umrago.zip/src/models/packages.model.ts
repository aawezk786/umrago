export class packages {
    id : number;
    packName: string;
    days : number;
    mkHotel : string;
    mdHotel : string;
    mkRating : number;
    mdRating : number;
    mkDist : number;
    mdDist : number;
    flightRoute : boolean;
    price  : number
    
}